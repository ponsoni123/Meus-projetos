package mapaprogramaçãoii;

import mapaprogramaçãoii.view.TelaLogin;


public class MapaProgramaçãoII {

   
    public static void main(String[] args) {
       
        TelaLogin tl = new TelaLogin ();
            tl.setVisible(true);
        
    }
    
}

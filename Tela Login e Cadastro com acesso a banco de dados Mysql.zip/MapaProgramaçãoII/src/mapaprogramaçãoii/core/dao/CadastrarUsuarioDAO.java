package mapaprogramaçãoii.core.dao;

import mapaprogramaçãoii.core.dao.conexao.ConexaoJDBC;
import mapaprogramaçãoii.core.entity.CadastroUsuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

      

public class CadastrarUsuarioDAO {
    
        public void inserir (CadastroUsuario cadastrousuario){
        
         String sql = " insert into usuario(nome, login, senha, email) values (?,?,?,?)";
              
        PreparedStatement ps;
       
        try{
        ps = ConexaoJDBC.getConexao().prepareStatement (sql);
        ps.setString(1,cadastrousuario.getNome());
        ps.setString(2, cadastrousuario.getLogin());
        ps.setString(3, cadastrousuario.getSenha());
        ps.setString(4, cadastrousuario.getEmail());
        
        ps.execute();
        
      
        
        }catch(SQLException e){
         e.printStackTrace();  
        }
         
    }
    
    
    public boolean buscarUsuarioporLogin (String login, String senha){
        
        String sql = "SELECT id, nome, login, senha , email from usuario where login = ? and senha = ?";
        
        PreparedStatement ps;
        ResultSet rs;
        boolean check = false;
        
        try{
            ps = ConexaoJDBC.getConexao().prepareStatement(sql);
            
            ps.setString(1,login);
            ps.setString(2, senha);
            
            rs = ps.executeQuery();
            
            
            if(rs.next()){
                CadastroUsuario usuario = new CadastroUsuario();
                usuario.setId(rs.getLong("ID"));
                usuario.setNome(rs.getString("NOME"));
                usuario.setLogin(rs.getString("LOGIN"));
                usuario.setSenha(rs.getString("SENHA"));
                usuario.setEmail(rs.getString("EMAIL"));
                return true;
            }
            return false;      
        
        }catch(SQLException e){
                
        }
        
        return false;
          
    }
              
}

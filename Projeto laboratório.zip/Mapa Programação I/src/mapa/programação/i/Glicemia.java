package mapa.programação.i;

import javax.swing.JOptionPane;


public class Glicemia extends Exame {
    
    private int qtdGlicose;
    
    
            public int getQtdGlicose() {
        return qtdGlicose;
    }

    public void setQtdGlicose(int qtdGlicose) {
        this.qtdGlicose = qtdGlicose;
    }
   
    
    @Override
    public void cadastrarExame(){
        super.cadastrarExame();
        this.qtdGlicose = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de glicose por mg/l:"));
        this.idade = 2023 - this.getAnoNascimento();
    }
    
    @Override
    public void mostrarResultado(){
       String msg = "Nome: " + this.getNome() + "\nQuantidade de glicose: " + this.qtdGlicose + "\nClassificação: "+classificarResultado();
              JOptionPane.showMessageDialog(null, msg);
    }
    
   
    public String classificarResultado(){
        if(getQtdGlicose() < 100){ 
            return "Normoglicemia";
        }
          
  
        else if (getQtdGlicose() >= 100 && getQtdGlicose() < 126){
           return "Pré-diabetes";
        } 

        
        else if (getQtdGlicose() >= 126){
           return "Diabetes estabelecido";
        }
        return null;
    }   
   
    
   }   
package mapa.programação.i;

import javax.swing.JOptionPane;

public class Triglicerídeos extends Exame {

    private int qtdTrigli;

    public int getQtdTrigli() {
        return qtdTrigli;
    }

    public void setQtdTrigli(int qtdTrigli) {
        this.qtdTrigli = qtdTrigli;
    }
            
    @Override
    public void cadastrarExame(){
        super.cadastrarExame();
        this.qtdTrigli = Integer.parseInt(JOptionPane.showInputDialog("Digite o nivel de triglicerideos por mg/l:"));
        this.idade = 2023 - this.getAnoNascimento();
        
    }
    
    @Override
    public void mostrarResultado(){
       String msg = "Nome: " + this.getNome() + "\nQuantidade de Triglicerídeos: " + this.qtdTrigli + "\nClassificação: "+classificarResultado();
      JOptionPane.showMessageDialog(null, msg);
    }
    
    public String classificarResultado(){
        if (this.idade <= 9 && this.qtdTrigli < 75){
        return "Triglicerídeo Bom";        
        }    
                      
         
        else if (this.idade >= 10 && this.idade <=19 && this.qtdTrigli < 90){
         return "Triglicerídeo bom";
        }    
                    
        
        
               
        else if (this.idade > 20 && this.qtdTrigli < 150){
           return "Triglicerídeo bom";
        }   
            
        
        
        else {
            return "Triglicerídeo ruim";
        }
            
            

    }
    
   
        
        

    
}

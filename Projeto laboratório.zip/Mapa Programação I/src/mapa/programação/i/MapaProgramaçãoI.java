package mapa.programação.i;


public class MapaProgramaçãoI {

    
    public static void main(String[] args) {
     
          
     //Exame exame = new Exame();
     //exame.cadastrarExame();
     //exame.mostrarResultado();
     
     Glicemia Glicemia = new Glicemia();
     Glicemia.cadastrarExame();
     Glicemia.mostrarResultado();
    
     
     
     Triglicerídeos Triglicerídeos = new Triglicerídeos();
     Triglicerídeos.cadastrarExame();
     Triglicerídeos.mostrarResultado();
    
     
     Colesterol Colesterol = new Colesterol();
     Colesterol.cadastrarExame();
     Colesterol.mostrarResultado();
   
     
        
    }
    
}

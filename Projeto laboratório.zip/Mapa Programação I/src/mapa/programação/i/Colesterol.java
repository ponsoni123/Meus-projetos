package mapa.programação.i;

import javax.swing.JOptionPane;


public class Colesterol extends Exame{
    
    private int qtdLDL;
    private int qtdHDL;
    private String riscoPaciente;

    public int getQtdLDL() {
        return qtdLDL;
    }

    public void setQtdLDL(int qtdLDL) {
        this.qtdLDL = qtdLDL;
    }

    public int getQtdHDL() {
        return qtdHDL;
    }

    public void setQtdHDL(int qtdHDL) {
        this.qtdHDL = qtdHDL;
    }

    public String getRiscoPaciente() {
        return riscoPaciente;
    }

    public void setRiscoPaciente(String riscoPaciente) {
        this.riscoPaciente = riscoPaciente;
    }
    
        
    @Override
    public void cadastrarExame(){
        super.cadastrarExame();
        this.qtdLDL = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de LDL por mg/l:"));
        this.qtdHDL = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de HDL por mg/l:"));
        this.riscoPaciente = (JOptionPane.showInputDialog("Qual é o risco do paciente? B = baixo, M = medio e A = alto"));
        this.idade = 2023 - this.getAnoNascimento();
    }
    
    @Override
    public void mostrarResultado(){
      String msg = "Nome: " + this.getNome() + "\nQuantidade de Colesterol LDL: " + this.qtdLDL + "\nClassificação : " +classificarResultadoLDL() + "\nQuantidade de Colesterol HDL: " + this.qtdHDL + "\n Classificação " +classificarResultadoHDL();
      JOptionPane.showMessageDialog(null, msg);
    }
    
     public String classificarResultadoHDL(){
        if (this.idade <= 19 && this.qtdHDL > 45){
          return "HDL - BOM";
        }    
              
                      
        else if (this.idade > 20 && this.qtdHDL > 40){
           return "HDL - BOM";
        }    
            
       
        else{
            return "HDL - RUIM";
        }        
                   
     }
    
     
      public String classificarResultadoLDL(){
        if ("B".equals(this.riscoPaciente) && this.qtdLDL < 100){
            return "LDL - BOM";
        }            
       
                                    
        else if ("M".equals(this.riscoPaciente) && this.qtdLDL < 70){
            return "LDL - BOM";
                 
        } 
        
        else if ("A".equals(this.riscoPaciente) && this.qtdHDL < 50){
          return "LDL - BOM";
        }    
        else{
            return "LDL - RUIM";
     }
    
      }
    
    
    
}
